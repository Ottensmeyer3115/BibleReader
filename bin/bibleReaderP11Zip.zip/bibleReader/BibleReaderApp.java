package bibleReader;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import bibleReader.model.ArrayListBible;
import bibleReader.model.Bible;
import bibleReader.model.BibleReaderModel;
import bibleReader.model.ReferenceList;
import bibleReader.model.ResultType;
import bibleReader.model.VerseList;

/**
 * The main class for the Bible Reader Application.
 * 
 * @author Fredrick Ottensmeyer
 */
public class BibleReaderApp extends JFrame {
	
	protected static final int width = 800;
	protected static final int height = 600;

	public static void main(String[] args) {
		new BibleReaderApp();
	}

	// Fields
	private BibleReaderModel model;
	private ResultView resultView;
	public JTextField searchField;
	public JButton PassageButton;
	public JButton searchButton;


	/**
	 * Default constructor. Creates the main panel layout which implements the ResultView Layout.
	 */
	public BibleReaderApp() {
		
		model = new BibleReaderModel(); //call the default constructor.
		searchField = new JTextField(10);
										
		File kjvFile = new File("kjv.atv");
		VerseList verses = BibleIO.readBible(kjvFile);
		Bible kjv = new ArrayListBible(verses);
		model.addBible(kjv);
		
		File esvFile = new File("esv.atv");
		verses = BibleIO.readBible(esvFile);
		Bible esv = new ArrayListBible(verses);
		model.addBible(esv);
		
		File asvFile = new File("asv.xmv");
		verses = BibleIO.readBible(asvFile);
		Bible asv = new ArrayListBible(verses);
		model.addBible(asv);

		resultView = new ResultView(model);

		setupGUI();
		pack();
		setSize(width, height);

		// So the application exits when you click the "x".
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	/**
	 * Set up the main GUI. This main GUI uses the ResultView GUI.
	 */
	private void setupGUI() {
		this.setLayout(new BorderLayout());
		
		searchButton = new JButton("Search");
		searchButton.setName("SearchButton");
		searchButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent s) {
				
				ReferenceList list = model.getReferencesContaining(searchField.getText());
				resultView.displaySearchResults(list, searchField.getText(), ResultType.SEARCH);
				
			}
				
		});	
		
		PassageButton = new JButton("Passage");
		PassageButton.setName("PassageButton");
		PassageButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent s) {
				
				ReferenceList list = model.getReferencesForPassage(searchField.getText());
				resultView.displaySearchResults(list, searchField.getText(), ResultType.PASSAGE);
			}
				
		});
		
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		menuBar.add(fileMenu);
		JMenuItem exit = new JMenuItem("Exit");
		fileMenu.add(exit);
		exit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.exit(0);
			}
		});
		
		JMenu helpMenu = new JMenu("Help");
		menuBar.add(helpMenu);
		JMenuItem about = new JMenuItem("About");
		helpMenu.add(about);
		about.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JOptionPane.showMessageDialog(getJFrame(), "This program searches various versions of the bible for words and passages and out"
						+ "puts the results in a list format. Written by Charles Cusack, Frederick Ootensmeyer, and Grace DuMez");
			}
		});
		
		Container contents = this.getContentPane();
		JPanel panel = new JPanel();
		contents.add(panel, BorderLayout.SOUTH);
		contents.add(resultView, BorderLayout.CENTER);
		searchField.setName("InputTextField");
		panel.add(searchButton);
		panel.add(searchField);
		panel.add(PassageButton);
		setJMenuBar(menuBar);
		this.pack();
		setVisible(true);
		
       
		// The stage numbers below may change, so make sure to pay attention to
		// what the assignment says.
		// TODO Add passage lookup: Stage ?
		// TODO Add 2nd version on display: Stage ?
		// TODO Limit the displayed search results to 20 at a time: Stage ?
		// TODO Add 3rd versions on display: Stage ?
		// TODO Format results better: Stage ?
		// TODO Display cross references for third version: Stage ?
		// TODO Save/load search results: Stage ?
	}

	public JFrame getJFrame(){
		return this;
	}
	
}
