package bibleReader;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bibleReader.model.BibleReaderModel;
import bibleReader.model.NavigableResults;
import bibleReader.model.ReferenceList;
import bibleReader.model.ResultType;
import bibleReader.model.Reference;
import bibleReader.model.Verse;
import bibleReader.model.VerseList;

/**
 * The display panel for the Bible Reader.
 * 
 * @author Fredrick Ottensmeyer and Grace DuMez
 */
public class ResultView extends JPanel {

	private JScrollPane scrollPane;
	private JTextArea textArea;
	public JEditorPane editorPane;
	public JButton previousButton;
	public JButton nextButton;
	public NavigableResults navRes;
	private JTextField resultsField;
	private BibleReaderModel bibleModel = new BibleReaderModel();

	// You will probably want to use a JScrollPane and JTextArea or JEditorPane
	// for this, possibly in addition to some textfields, etc.
	// JEditorPanes can be set up to display simple HTML, which will come
	// in handy in future stages, so you might look into this.

	/**
	 * Construct a new ResultView and set its model to myModel. It needs to
	 * model to look things up.
	 * 
	 * @param myModel
	 *            The model this view will access to get information.
	 */
	public ResultView(BibleReaderModel myModel) {

		this.bibleModel = myModel;
		makePanes();
	}

	/**
	 * This method will create a new EditorPane and ScrollPane. and place the
	 * Scroll Pane onto the editor Pane. And set the two panes making them
	 * visible on the content window on the BibleReaderApp.
	 */
	public void makePanes() {
		setLayout(new BorderLayout(10, 10));

		editorPane = new JEditorPane();
		editorPane.setContentType("text/html");
		editorPane.setEditable(false);

		scrollPane = new JScrollPane(editorPane);
		editorPane.setName("OutputEditorPane");
		scrollPane.setPreferredSize(new Dimension(600, 300));

		resultsField = new JTextField(50);

		// scrollPane.add(editorPane);
		this.add(resultsField);
		this.add(scrollPane);

		previousButton = new JButton("Previous Results");
		previousButton.setEnabled(false);
		previousButton.setName("PreviousButton");
		previousButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent s) {
				if (navRes.hasPreviousResults()) {
					navRes.previousResults();
					updateButtons();
					printSearchResults();
				}
			}

		});

		nextButton = new JButton("Next Results");
		nextButton.setEnabled(false);
		nextButton.setName("NextButton");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent s) {
				if (navRes.hasNextResults()) {
					navRes.nextResults();
					updateButtons();
					printSearchResults();
				}
			}
		});

		JPanel panel = new JPanel();
		panel.add(previousButton);
		this.add(panel, BorderLayout.SOUTH);
		panel.add(nextButton);
		this.add(panel, BorderLayout.SOUTH);
		setVisible(true);
	}

	/**
	 * 
	 */
	public void updateButtons() {
		if (navRes.hasPreviousResults()) {
			previousButton.setEnabled(true);
		} else {
			previousButton.setEnabled(false);
		}

		if (navRes.hasNextResults()) {
			nextButton.setEnabled(true);
		} else {
			nextButton.setEnabled(false);
		}

	}

	/**
	 * 
	 */
	public void printSearchResults() {

		StringBuffer buffer = new StringBuffer();
		if (navRes.getType() == ResultType.PASSAGE) {
			ReferenceList RL = navRes.currentResults();
			Reference firstRef = RL.get(0);
			Reference lastRef = RL.get(RL.size() - 1);
			buffer.append("<center><b>");
			if (lastRef.getBookOfBible().equals(firstRef.getBookOfBible())) {
				if (lastRef.getChapter() == firstRef.getChapter()) {
					buffer.append(firstRef.toString());
					buffer.append("-");
					buffer.append(lastRef.getVerse());
				} else {
					buffer.append(firstRef.toString());
					buffer.append("-");
					buffer.append(lastRef.getChapter());
					buffer.append(":");
					buffer.append(lastRef.getVerse());
				}
			} else {
				buffer.append(firstRef.toString());
				buffer.append("-");
				buffer.append(lastRef.toString());
			}
			buffer.append("</b></center>");
			buffer.append("<table>");
			buffer.append("<tr>");
			String[] versions = bibleModel.getVersions();
			for (int i = 0; i < versions.length; i++) {
				buffer.append("<td>" + versions[i] + "</td>");
			}
			buffer.append("</tr>");
			buffer.append("<tr>");
			for (int i = 0; i < versions.length; i++) {
				buffer.append("<td>");
				buffer.append("<p>");
				for (Reference r : navRes.currentResults()) {
					if(bibleModel.getBible(versions[i]).getVerse(r) == null){
						continue;
					}
					if(r.getVerse()==1){
						buffer.append("</p><p></p><p>");
						buffer.append("<sup><b>");
						buffer.append(r.getChapter());
						buffer.append("</b></sup>");
					}else{
						buffer.append("<sup>");
						buffer.append(r.getVerse());
						buffer.append("</sup>");
					}
					buffer.append(bibleModel.getBible(versions[i]).getVerse(r).getText());
					buffer.append(" ");
				}
				buffer.append("</p>");
				buffer.append("</td>");
			}
			buffer.append("</tr></table>");
		} else {
			buffer.append("<table>");
			buffer.append("<tr valign='top'>");
			buffer.append("<td>");
			buffer.append("Reference");
			buffer.append("</td>");
			String[] versions = bibleModel.getVersions();
			for (int i = 0; i < versions.length; i++) {
				buffer.append("<td>" + versions[i] + "</td>");
			}
			buffer.append("</tr>");

			for (Reference r : navRes.currentResults()) {
				buffer.append("<tr valign='top'>");
				buffer.append("<td>");
				buffer.append(r.toString());
				buffer.append("</td>");
				for (int i = 0; i < versions.length; i++) {
					Verse v = bibleModel.getBible(versions[i]).getVerse(r);
					buffer.append("<td>");
					if (v != null) {
						String phrase = v.getText();
						if (navRes.getType() == ResultType.SEARCH) {
							String word = navRes.getQueryPhrase();
							phrase = phrase.replaceAll("(?i)" + word, "<b>$0</b>");
						}
						buffer.append(phrase);
					}
					buffer.append("</td>");
				}
				buffer.append("</tr>");
			}
			buffer.append("</table>");
		}
		editorPane.setText(buffer.toString());
	}

	/**
	 * This is the action GUI method. This will create and set up the table. As
	 * well as get into the BibleReaderModel to retrieve the: Version, Text, and
	 * Reference. And set them up in a consistent ordering that the user can
	 * read.
	 * 
	 * @param references
	 * @param text
	 */
	public void displaySearchResults(ReferenceList references, String text, ResultType type) {
		editorPane.setCaretPosition(0);
		StringBuffer buffer = new StringBuffer();
		navRes = new NavigableResults(references, text, type);
		if (references.isEmpty()) {
			buffer.append("No results were found for the search query of ");
			buffer.append(text);
			editorPane.setText(buffer.toString());
			updateButtons();
		} else {
			updateButtons();
			printSearchResults();
		}

	}

}
