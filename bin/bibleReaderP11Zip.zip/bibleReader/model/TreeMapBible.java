package bibleReader.model;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * A class that stores a version of the Bible.
 * 
 * @author Chuck Cusack (Provided the interface)
 * @author ? (provided the implementation)
 */
public class TreeMapBible implements Bible {

	// The Fields
	private String version;
	private String description;
	private TreeMap<Reference, Verse> theVerses;

	// Or replace the above with:
	// private TreeMap<Reference, Verse> theVerses;
	// Add more fields as necessary.

	/**
	 * Create a new Bible with the given verses.
	 * 
	 * @param version
	 *            the version of the Bible (e.g. ESV, KJV, ASV, NIV).
	 * @param verses
	 *            All of the verses of this version of the Bible.
	 */
	public TreeMapBible(VerseList verses) {
		version = verses.getVersion();
		description = verses.getDescription();
		theVerses = new TreeMap<Reference, Verse>();
		for (Verse verse : verses) {
			theVerses.put(verse.getReference(), verse);
		}
	}

	@Override
	public int getNumberOfVerses() {
		return theVerses.size();
	}

	@Override
	public VerseList getAllVerses() {
		VerseList vl = new VerseList(version, description);
		vl.addAll(theVerses.values());
		return vl;
	}

	@Override
	public String getVersion() {
		return version;
	}

	@Override
	public String getTitle() {
		return description;
	}

	@Override
	public boolean isValid(Reference ref) {
		if (ref.getBookOfBible() == BookOfBible.Dummy) {
			return false;
		}
		for (Reference r : theVerses.keySet()) {
			if (r.equals(ref)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String getVerseText(Reference r) {
		if(!isValid(r)){
			return null;
		}
		return theVerses.get(r).getText();
	}

	@Override
	public Verse getVerse(Reference r) {
		return theVerses.get(r);
	}

	@Override
	public Verse getVerse(BookOfBible book, int chapter, int verse) {
		Reference r = new Reference(book, chapter, verse);
		return getVerse(r);
	}

	// ---------------------------------------------------------------------------------------------
	// The following part of this class should be implemented for stage 4.
	//
	// For Stage 11 the first two methods below will be implemented as specified
	// in the comments.
	// Do not over think these methods. All three should be pretty
	// straightforward to implement.
	// For Stage 8 (give or take a 1 or 2) you will re-implement them so they
	// work better.
	// At that stage you will create another class to facilitate searching and
	// use it here.
	// (Essentially these two methods will be delegate methods.)
	// ---------------------------------------------------------------------------------------------

	@Override
	public VerseList getVersesContaining(String phrase) {
		VerseList VL = new VerseList(version, phrase);
		if (phrase.equals("")) {
			return VL;
		}
		for (Entry<Reference, Verse> v : theVerses.entrySet()) {
			if (v.getValue().getText().toLowerCase().contains(phrase.toLowerCase())) {
				VL.add(v.getValue());
			}
		}
		return VL;
	}

	@Override
	public ReferenceList getReferencesContaining(String phrase) {
		ReferenceList RL = new ReferenceList();
		if (phrase.equals("")) {
			return RL;
		}
		for (Entry<Reference, Verse> v : theVerses.entrySet()) {
			if (v.getValue().getText().toLowerCase().contains(phrase.toLowerCase())) {
				RL.add(v.getKey());
			}
		}
		return RL;
	}

	@Override
	public VerseList getVerses(ReferenceList references) {
		VerseList VL = new VerseList(version, "some stuff");
		for (Reference r : references) {
			if (isValid(r)) {
				VL.add(theVerses.get(r));
			}else{
				VL.add(null);
			}
		}

		return VL;
	}

	// ---------------------------------------------------------------------------------------------
	// The following part of this class should be implemented for Stage 11.
	//
	// HINT: Do not reinvent the wheel. Some of these methods can be implemented
	// by looking up
	// one or two things and calling another method to do the bulk of the work.
	// ---------------------------------------------------------------------------------------------

	@Override
	public int getLastVerseNumber(BookOfBible book, int chapter) {
		int lastVerseNumber = -1;
		Reference r = theVerses.lowerKey(new Reference(book, chapter + 1, 1));
		if (r != null) {
			lastVerseNumber = r.getVerse();
		}
		return lastVerseNumber;
	}

	@Override
	public int getLastChapterNumber(BookOfBible book) {
		int lastChapterNumber = -1;
		Reference r = theVerses.lowerKey(new Reference(BookOfBible.nextBook(book), 1, 1));
		if (r != null) {
			lastChapterNumber = r.getChapter();
		}
		return lastChapterNumber;
	}

	@Override
	public ReferenceList getReferencesInclusive(Reference firstVerse, Reference lastVerse) {
		if (!isValid(firstVerse) || !isValid(lastVerse)) {
			return new ReferenceList();
		}
		if (firstVerse.compareTo(lastVerse) > 0) {
			return new ReferenceList();
		}
		ReferenceList inclusiveResults = getReferencesExclusive(firstVerse, lastVerse);
		inclusiveResults.add(lastVerse);
		return inclusiveResults;
	}

	@Override
	public ReferenceList getReferencesExclusive(Reference firstVerse, Reference lastVerse) {
		boolean insideRange = false;
		ReferenceList exclusiveResults = new ReferenceList();
		if (!isValid(firstVerse)) {
			return exclusiveResults;
		}
		if (firstVerse.compareTo(lastVerse) > 0) {
			return exclusiveResults;
		}

		for (Reference r : theVerses.keySet()) {
			if (r.equals(firstVerse)) {
				insideRange = true;
			}

			if (r.compareTo(lastVerse) >= 0) {
				insideRange = false;
				return exclusiveResults;
			}

			if (insideRange) {
				exclusiveResults.add(r);
			}
		}
		return exclusiveResults;
	}

	@Override
	public ReferenceList getReferencesForBook(BookOfBible book) {
		if(book == null){
			return new ReferenceList();
		}
		Reference firstVerse = new Reference(book, 1, 1);
		Reference lastVerse = new Reference(book, getLastChapterNumber(book),
				getLastVerseNumber(book, getLastChapterNumber(book)));

		return getReferencesInclusive(firstVerse, lastVerse);
	}

	@Override
	public ReferenceList getReferencesForChapter(BookOfBible book, int chapter) {
		Reference firstVerse = new Reference(book, chapter, 1);
		Reference lastVerse = new Reference(book, chapter, getLastVerseNumber(book, chapter));

		return getReferencesInclusive(firstVerse, lastVerse);
	}

	@Override
	public ReferenceList getReferencesForChapters(BookOfBible book, int chapter1, int chapter2) {
		Reference firstVerse = new Reference(book, chapter1, 1);
		Reference lastVerse = new Reference(book, chapter2, getLastVerseNumber(book, chapter2));

		return getReferencesInclusive(firstVerse, lastVerse);
	}

	@Override
	public ReferenceList getReferencesForPassage(BookOfBible book, int chapter, int verse1, int verse2) {
		Reference firstVerse = new Reference(book, chapter, verse1);
		Reference lastVerse = new Reference(book, chapter, verse2);

		return getReferencesInclusive(firstVerse, lastVerse);
	}

	@Override
	public ReferenceList getReferencesForPassage(BookOfBible book, int chapter1, int verse1, int chapter2, int verse2) {
		Reference firstVerse = new Reference(book, chapter1, verse1);
		Reference lastVerse = new Reference(book, chapter2, verse2);

		return getReferencesInclusive(firstVerse, lastVerse);
	}

	@Override
	public VerseList getVersesInclusive(Reference firstVerse, Reference lastVerse) {
		
		if(!isValid(firstVerse) || !isValid(lastVerse)){
			return new VerseList("","");
		}
		if(firstVerse.compareTo(lastVerse) > 0){
			return new VerseList("","");
		}
		VerseList inclusiveResults = getVersesExclusive(firstVerse, lastVerse);
		inclusiveResults.add(theVerses.get(lastVerse));
		
		return inclusiveResults;
	}

	@Override
	public VerseList getVersesExclusive(Reference firstVerse, Reference lastVerse) {
		// Implementation of this method provided by Chuck Cusack.
		// This is provided so you have an example to help you get started
		// with the other methods.

		// We will store the resulting verses here. We copy the version from
		// this Bible and set the description to be the passage that was
		// searched for.
		VerseList someVerses = new VerseList(getVersion(), firstVerse + "-" + lastVerse);

		// Make sure the references are in the correct order. If not, return an
		// empty list.
		if (firstVerse.compareTo(lastVerse) > 0) {
			return someVerses;
		}
		// Return the portion of the TreeMap that contains the verses between
		// the first and the last, not including the last.
		SortedMap<Reference, Verse> s = theVerses.subMap(firstVerse, lastVerse);

		// Get the entries from the map so we can iterate through them.
		Set<Map.Entry<Reference, Verse>> mySet = s.entrySet();

		// Iterate through the set and put the verses in the VerseList.
		for (Map.Entry<Reference, Verse> element : mySet) {
			someVerses.add(element.getValue());
		}
		return someVerses;
	}

	@Override
	public VerseList getBook(BookOfBible book) {
		if(book == null){
			return new VerseList("","");
		}
		Reference firstVerse = new Reference(book, 1, 1);
		Reference lastVerse = new Reference(book, getLastChapterNumber(book),
				getLastVerseNumber(book, getLastChapterNumber(book)));

		return getVersesInclusive(firstVerse, lastVerse);
	}

	@Override
	public VerseList getChapter(BookOfBible book, int chapter) {
		Reference firstVerse = new Reference(book, chapter, 1);
		Reference lastVerse = new Reference(book, chapter, getLastVerseNumber(book, chapter));

		return getVersesInclusive(firstVerse, lastVerse);
	}

	@Override
	public VerseList getChapters(BookOfBible book, int chapter1, int chapter2) {
		Reference firstVerse = new Reference(book, chapter1, 1);
		Reference lastVerse = new Reference(book, chapter2, getLastVerseNumber(book, chapter2));

		return getVersesInclusive(firstVerse, lastVerse);
	}

	@Override
	public VerseList getPassage(BookOfBible book, int chapter, int verse1, int verse2) {
		Reference firstVerse = new Reference(book, chapter, verse1);
		Reference lastVerse = new Reference(book, chapter, verse2);

		return getVersesInclusive(firstVerse, lastVerse);
	}

	@Override
	public VerseList getPassage(BookOfBible book, int chapter1, int verse1, int chapter2, int verse2) {
		Reference firstVerse = new Reference(book, chapter1, verse1);
		Reference lastVerse = new Reference(book, chapter2, verse2);

		return getVersesInclusive(firstVerse, lastVerse);
	}

}
