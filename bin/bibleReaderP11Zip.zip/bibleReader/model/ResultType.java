package bibleReader.model;

/**
 * The type of query.
 * It isn't clear where this belongs, so we will put it in its own file.
 * @author cusack
 *
 */
public enum ResultType {
	NONE, SEARCH, PASSAGE
}