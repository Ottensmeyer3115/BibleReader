package bibleReader.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The model of the Bible Reader. It stores the Bibles and has methods for
 * searching for verses based on words or references.
 * 
 * @author Fredrick Ottensmeyer and Grace DuMez, February 20th, 2017
 */
public class BibleReaderModel implements MultiBibleModel {

	// ---------------------------------------------------------------------------

	// One field of type HashMap. This is used to map several Bible Objects to a
	// String.
	private HashMap<String, Concordance> concordances;
	private HashMap<String, Bible> bibles;

	/**
	 * Construction instantiates the field: bibles. The following methods are
	 * for stage 5.
	 */
	public BibleReaderModel() {
		concordances = new HashMap<String, Concordance>();
		bibles = new HashMap<String, Bible>();
	}

	/**
	 * This method will get all the versions by going into the bibles HashMap
	 * and matching the key (String) and converting the keySet to an Array.
	 * 
	 * @return the String[].
	 */
	@Override
	public String[] getVersions() {

		String[] versions = new String[bibles.size()];
		int i = 0;
		for (String version : bibles.keySet()) {
			versions[i] = version;
			i++;
		}
		Arrays.sort(versions);
		return versions;
	}

	/**
	 * This method will go into the bibles HashMap and get the total number of
	 * keys.
	 * 
	 * @return the size of the keySet(number of versions).
	 */
	@Override
	public int getNumberOfVersions() {
		return bibles.keySet().size();
	}

	/**
	 * This method will go into the bibles HashMap and grab a specific version
	 * of a bible. And store that version in the HashMap.
	 */
	@Override
	public void addBible(Bible bible) {
		bibles.put(bible.getVersion(), bible);
		concordances.put(bible.getVersion(), new Concordance(bible));
	}

	/**
	 * This method will go into the bibles HashMap and grab a specific version
	 * of a bible.
	 * 
	 * @return the Bible object from the HashMap.
	 */
	@Override
	public Bible getBible(String version) {
		return bibles.get(version);
	}

	/**
	 * This method will create a ReferenceList. Then iterate through the bibles
	 * HashMap Values, and find the "words" the user inputs, as long as it isn't
	 * null. Then store all of the matches to "words" the user inputs into the
	 * Reference List.
	 * 
	 * @return ReferenceList.
	 */
	@Override
	public ReferenceList getReferencesContaining(String words) {

		TreeSet<Reference> reference = new TreeSet<Reference>();
		for (Bible bible : bibles.values()) {
			if (bible.getReferencesContaining(words) == null) {
				return null;
			} else {
				reference.addAll(bible.getReferencesContaining(words));
			}
		}
		return new ReferenceList(reference);
	}

	/**
	 * This method will create a new Verse List with the parameters version and
	 * empty string(""). Then iterate through the bibles HashMap values, and
	 * store the values that match the version and references the user inputs.
	 * And store those into the verse List.
	 *
	 * @return VerseList
	 */
	@Override
	public VerseList getVerses(String version, ReferenceList references) {

		// VerseList VL = new VerseList(version, "");
		// TreeSet<Verse> versionSet = new TreeSet<Verse>();
		for (Bible bible : bibles.values()) {
			if (bible.getVersion().equals(version)) {
				return bible.getVerses(references);
			}
		}
		return null;
		// VL = new VerseList(version, "", versionSet);
		// return VL;
	}

	@Override
	public String getText(String version, Reference reference) {
		Bible bible = bibles.get(version);
		if (bible == null)
			return "";
		String text = bible.getVerseText(reference);
		if (text == null) {
			return "";
		}
		return text;
	}

	public static Pattern bookPattern = Pattern.compile("\\s*((?:1|2|3|I|II|III)\\s*\\w+|(?:\\s*[a-zA-Z]+)+)\\s*(.*)");
	public static Pattern chapterversePattern = Pattern.compile("(\\d*)\\s*:\\s*(\\d*)\\s*");
	public static Pattern chapterversesPattern = Pattern.compile("(\\d*)\\s*:\\s*(\\d*)\\s*-\\s*(\\d*)\\s*");
	public static Pattern chapterPattern = Pattern.compile("(\\d*)(?:\\s*)");
	public static Pattern chaptersPattern = Pattern.compile("(\\d*)\\s*(?:-)\\s*(\\d*)\\s*");
	public static Pattern chaptersVersesPattern = Pattern
			.compile("(\\d*)\\s*:\\s*(\\d*)\\s*-\\s*(\\d*)\\s*:\\s*(\\d*)\\s*");
	public static Pattern multipleVersesOdd = Pattern.compile("(\\d*)\\s*-\\s*(\\d*)\\s*:\\s*(\\d*)\\s*");

	@Override
	public ReferenceList getReferencesForPassage(String reference) {
		ReferenceList refList = new ReferenceList();

		String refMatch = null;
		BookOfBible book;
		int chapter1, chapter2, verse1, verse2;

		Matcher m = bookPattern.matcher(reference);
		if (m.matches()) {
			book = BookOfBible.getBookOfBible(m.group(1));
			if (book == null) {
				return refList;
			}
			refMatch = m.group(2);
			try {
				if (refMatch.length() == 0) {
					refList = getBookReferences(book);
				} else if ((m = chapterversePattern.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					verse1 = Integer.parseInt(m.group(2));
					refList = getVerseReferences(book, chapter1, verse1);

				} else if ((m = chapterversesPattern.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					verse1 = Integer.parseInt(m.group(2));
					verse2 = Integer.parseInt(m.group(3));
					refList = getPassageReferences(book, chapter1, verse1, verse2);

				} else if ((m = chapterPattern.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					refList = getChapterReferences(book, chapter1);

				} else if ((m = chaptersPattern.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					chapter2 = Integer.parseInt(m.group(2));
					refList = getChapterReferences(book, chapter1, chapter2);

				} else if ((m = chaptersVersesPattern.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					verse1 = Integer.parseInt(m.group(2));
					chapter2 = Integer.parseInt(m.group(3));
					verse2 = Integer.parseInt(m.group(4));
					refList = getPassageReferences(book, chapter1, verse1, chapter2, verse2);

				} else if ((m = multipleVersesOdd.matcher(refMatch)).matches()) {
					chapter1 = Integer.parseInt(m.group(1));
					verse1 = 1;
					chapter2 = Integer.parseInt(m.group(2));
					verse2 = Integer.parseInt(m.group(3));
					refList = getPassageReferences(book, chapter1, verse1, chapter2, verse2);

				} else {
					// Invalid format for chapters and verses
				}
			} catch (NumberFormatException e) {
				return refList;
			}
		} else {
			// Invalid format for book of bible
		}

		return refList;
	}

	// -----------------------------------------------------------------------------
	// The next set of methods are for use by the getReferencesForPassage method
	// above.
	// After it parses the input string it will call one of these.
	//
	// These methods should be somewhat easy to implement. They are kind of
	// delegate
	// methods in that they call a method on the Bible class to do most of the
	// work.
	// However, they need to do so for every version of the Bible stored in the
	// model.
	// and combine the results.
	//
	// Once you implement one of these, the rest of them should be fairly
	// straightforward.
	// Think before you code, get one to work, and then implement the rest based
	// on
	// that one.
	// -----------------------------------------------------------------------------

	@Override
	public ReferenceList getVerseReferences(BookOfBible book, int chapter, int verse) {

		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			Verse v = bibles.get(version).getVerse(book, chapter, verse);
			if (v != null) {
				referenceSet.add(v.getReference());
			}
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getPassageReferences(Reference startVerse, Reference endVerse) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesInclusive(startVerse, endVerse));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getBookReferences(BookOfBible book) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesForBook(book));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getChapterReferences(BookOfBible book, int chapter) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesForChapter(book, chapter));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getChapterReferences(BookOfBible book, int chapter1, int chapter2) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesForChapters(book, chapter1, chapter2));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getPassageReferences(BookOfBible book, int chapter, int verse1, int verse2) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesForPassage(book, chapter, verse1, verse2));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getPassageReferences(BookOfBible book, int chapter1, int verse1, int chapter2, int verse2) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (String version : bibles.keySet()) {
			referenceSet.addAll(bibles.get(version).getReferencesForPassage(book, chapter1, verse1, chapter2, verse2));
		}
		return new ReferenceList(referenceSet);
	}

	// ------------------------------------------------------------------
	// These are the better searching methods.
	//
	@Override
	public ReferenceList getReferencesContainingWord(String word) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		for (Concordance concordance : concordances.values()) {
			referenceSet.addAll(concordance.getReferencesContaining(word));
		}
		return new ReferenceList(referenceSet);
	}

	@Override
	public ReferenceList getReferencesContainingAllWords(String words) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		ReferenceList results = new ReferenceList(referenceSet);
		if (words != "") {
			ArrayList<String> list = Concordance.extractWords(words.toLowerCase());
			for (Concordance concordance : concordances.values()) {
				referenceSet.addAll(concordance.getReferencesContainingAll(list));
			}
			results = new ReferenceList(referenceSet);
		}
		return results;
	}

	@Override
	public ReferenceList getReferencesContainingAllWordsAndPhrases(String words) {
		TreeSet<Reference> referenceSet = new TreeSet<Reference>();
		ArrayList<String> phrases = new ArrayList<String>();
		if (words != "") {
			if (!words.contains("\"")) {
				return getReferencesContainingAllWords(words);
			}
			boolean done = false;
			while (!done) {
				int begIndex = words.indexOf("\"");
				if (begIndex == -1) {
					done = true;
				}
				String phrase = words.substring(begIndex + 1);
				int endIndex = phrase.indexOf("\"");
				if (endIndex == -1) {
					words = words.substring(0, begIndex) + words.substring(begIndex + 1);
					done = true;
				}
				if (done != true) {
					phrases.add(words.substring(begIndex + 1, endIndex));
					words = words.substring(0, begIndex) + words.substring(endIndex + 1);
				}

			}
			referenceSet.addAll(getReferencesContainingAllWords(words));
			for(String phrase : phrases){
				referenceSet.retainAll(getReferencesContaining(phrase));
			}
		}
		return new ReferenceList(referenceSet);
	}
}
