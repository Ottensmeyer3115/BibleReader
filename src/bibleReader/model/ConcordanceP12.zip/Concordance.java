package bibleReader.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

/**
 * Concordance is a class which implements a concordance for a Bible. In other
 * words, it allows the easy lookup of all references which contain a given
 * word.
 * 
 * @author Chuck Cusack, March 2013 (Provided the interface)
 * @author ?, March 2013 (Provided the implementation details)
 */
public class Concordance {
	// Add fields here. (I actually only needed one field.)
	private HashMap<String, TreeSet<Reference>> RL;

	/**
	 * Construct a concordance for the given Bible.
	 */
	public Concordance(Bible bible) {
		RL = new HashMap<String, TreeSet<Reference>>();
		bible.getVersion();
		for (Verse verse : bible.getAllVerses()) {
			if (verse != null) {
				List<String> words = extractWords(verse.getText().toLowerCase());
				for (String currentWord : words) {
					String newWord = currentWord.trim().toLowerCase();
					if (!RL.containsKey(newWord)) {
						RL.put(newWord, new TreeSet<Reference>());
					}
					RL.get(newWord).add(verse.getReference());
				}
			}
		}
	}

	public static ArrayList<String> extractWords(String text) {
		text = text.toLowerCase();
		text = text.replaceAll("(<sup>[,\\w]*?</sup>|'s|�s|&#\\w*;)", " ");
		text = text.replaceAll(",", "");
		String[] words = text.split("\\W+");
		ArrayList<String> toRet = new ArrayList<String>(Arrays.asList(words));
		toRet.remove("");
		return toRet;
	}

	/**
	 * Return the list of references to verses that contain the word 'word'
	 * (ignoring case) in the version of the Bible that this concordance was
	 * created with.
	 * 
	 * @param word
	 *            a single word (no spaces, etc.)
	 * @return the list of References of verses from this version that contain
	 *         the word, or an empty list if no verses contain the word.
	 */
	public ReferenceList getReferencesContaining(String word) {
		// TODO: Implement me.
		// This one should only be a few lines if you implement this class
		// correctly
		String newWord = word.trim().toLowerCase();
		if (newWord == "") {
			return new ReferenceList();
		} else if (RL.get(newWord) != null) {
			ReferenceList reflist = new ReferenceList(RL.get(newWord));
			return reflist;
		} else {
			return new ReferenceList();
		}
	}

	/**
	 * Given an array of Strings, where each element of the array is expected to
	 * be a single word (with no spaces, etc., but ignoring case), return a
	 * ReferenceList containing all of the verses that contain <i>all of the
	 * words</i>.
	 * 
	 * @param words
	 *            A list of words.
	 * @return An ReferenceList containing references to all of the verses that
	 *         contain all of the given words, or an empty list if
	 */
	public ReferenceList getReferencesContainingAll(ArrayList<String> words) {
		// TODO: Implement me.
		// This one is a little more complicated, but is similar in many ways to
		// methods you have already implemented.
		if(words.isEmpty()){
			return new ReferenceList();
		}
		String newWord = words.get(0).trim().toLowerCase();
		ReferenceList reflis = getReferencesContaining(newWord);
		if (reflis == null) {
			return new ReferenceList();
		}
		for (String word : words) {
			newWord = word.trim().toLowerCase();
			if (RL.containsKey(newWord)) {
				reflis.retainAll(RL.get(newWord));
			} else{
				return new ReferenceList();
			}
		}
		return reflis;
	}
}
